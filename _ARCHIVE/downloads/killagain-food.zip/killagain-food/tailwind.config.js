/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        madras: {
          red: '#E11D48',
          yellow: '#FACC15',
          green: '#22C55E',
          blue: '#3B82F6'
        }
      }
    },
  },
  plugins: [],
}