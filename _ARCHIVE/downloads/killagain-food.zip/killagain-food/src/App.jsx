import React, { useState, useEffect } from 'react';
import { Heart, Instagram, Utensils, Clock, Flame, Search, ChevronRight, X } from 'lucide-react';

// Base de données des recettes
const RECIPES = [
  {
    id: 1, 
    title: "Bokits Poulet", 
    category: "Street Food", 
    time: "45 min", 
    diff: "Moyen",
    img: "https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?q=80&w=800",
    ingredients: ["500g farine", "1 sachet levure boulangère", "250ml eau tiède", "Sel", "Poulet boucané effiloché", "Sauce chien"],
    steps: ["Préparer la pâte à bokit et laisser reposer 2h.", "Former des boules et les aplatir.", "Frire dans une huile chaude.", "Garnir de poulet et de crudités."]
  },
  {
    id: 2,
    title: "Accras de Morue",
    category: "Entrée",
    time: "30 min",
    diff: "Facile",
    img: "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?q=80&w=800",
    ingredients: ["250g morue dessalée", "200g farine", "Piment antillais", "Cives", "Persil", "Levure chimique"],
    steps: ["Émietter la morue.", "Mélanger farine, eau, épices et morue.", "Former des petites boules avec une cuillère.", "Frire jusqu'à obtenir une couleur dorée."]
  },
  {
    id: 3,
    title: "Colombo de Poulet",
    category: "Plat",
    time: "1h15",
    diff: "Facile",
    img: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?q=80&w=800",
    ingredients: ["1 poulet découpé", "Poudre à colombo", "Graines de roussi", "Pommes de terre", "Ail", "Citron vert"],
    steps: ["Faire mariner le poulet avec citron et ail.", "Faire roussir les graines.", "Ajouter le poulet et le colombo.", "Laisser mijoter avec les pommes de terre."]
  },
  {
    id: 4,
    title: "Matété de Crabe",
    category: "Tradition",
    time: "2h00",
    diff: "Difficile",
    img: "https://images.unsplash.com/photo-1559740038-191442f47dfc?q=80&w=800",
    ingredients: ["8 crabes de terre", "Riz", "Cives", "Piment", "Clous de girofle", "Bois d'inde"],
    steps: ["Nettoyer les crabes soigneusement.", "Faire revenir avec les épices.", "Ajouter le riz et l'eau.", "Cuire à feu doux jusqu'à absorption."]
  }
];

export default function App() {
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState(() => JSON.parse(localStorage.getItem('favs') || '[]'));
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  useEffect(() => {
    localStorage.setItem('favs', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFav = (id, e) => {
    e.stopPropagation();
    setFavorites(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const filteredRecipes = RECIPES.filter(r => 
    r.title.toLowerCase().includes(search.toLowerCase()) ||
    r.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen pb-12">
      {/* Header Madras Style */}
      <header className="relative bg-white shadow-md border-b-4 madras-border">
        <div className="max-w-4xl mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex flex-col">
            <h1 className="text-3xl font-black text-madras-red tracking-tighter">
              KILLAGAIN <span className="text-madras-yellow">FOOD</span>
            </h1>
            <p className="text-xs font-bold text-madras-blue">SAVEURS CRÉOLES & AUTHENTIQUES</p>
          </div>
          <a 
            href="https://instagram.com/killagainfood" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600 p-2 rounded-full text-white"
          >
            <Instagram size={24} />
          </a>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 pt-8">
        {/* Search Bar */}
        <div className="relative mb-8">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="Rechercher un bokit, colombo..."
            className="w-full pl-10 pr-4 py-4 rounded-2xl border-2 border-slate-100 focus:border-madras-green outline-none shadow-sm transition-all"
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* Feed */}
        <div className="grid gap-6">
          {filteredRecipes.map(recipe => (
            <div 
              key={recipe.id}
              onClick={() => setSelectedRecipe(recipe)}
              className="group bg-white rounded-3xl overflow-hidden shadow-lg border border-slate-100 active:scale-95 transition-transform cursor-pointer"
            >
              <div className="relative h-56">
                <img src={recipe.img} alt={recipe.title} className="w-full h-full object-cover" />
                <button 
                  onClick={(e) => toggleFav(recipe.id, e)}
                  className="absolute top-4 right-4 p-3 rounded-full bg-white/90 shadow-md backdrop-blur-sm"
                >
                  <Heart 
                    size={20} 
                    className={favorites.includes(recipe.id) ? "fill-red-500 text-red-500" : "text-slate-400"}
                  />
                </button>
                <div className="absolute bottom-4 left-4 flex gap-2">
                  <span className="px-3 py-1 rounded-full bg-madras-yellow text-xs font-black uppercase">
                    {recipe.category}
                  </span>
                </div>
              </div>
              <div className="p-5 flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-bold text-slate-800">{recipe.title}</h2>
                  <div className="flex gap-4 mt-2 text-slate-500 text-sm">
                    <span className="flex items-center gap-1"><Clock size={14}/> {recipe.time}</span>
                    <span className="flex items-center gap-1"><Flame size={14}/> {recipe.diff}</span>
                  </div>
                </div>
                <ChevronRight className="text-slate-300" />
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Recipe Modal */}
      {selectedRecipe && (
        <div className="fixed inset-0 z-50 bg-white overflow-y-auto animate-in slide-in-from-bottom duration-300">
          <button 
            onClick={() => setSelectedRecipe(null)}
            className="fixed top-6 right-6 z-50 p-2 bg-black/50 text-white rounded-full backdrop-blur-md"
          >
            <X size={24} />
          </button>
          
          <div className="h-80 w-full">
            <img src={selectedRecipe.img} className="w-full h-full object-cover" />
          </div>
          
          <div className="p-6 -mt-10 relative bg-white rounded-t-[40px]">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-3xl font-black text-slate-900">{selectedRecipe.title}</h2>
                <p className="text-madras-green font-bold">{selectedRecipe.category}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-slate-50 p-4 rounded-2xl border-b-4 border-madras-blue">
                <p className="text-xs text-slate-500 uppercase font-bold">Temps</p>
                <p className="font-bold">{selectedRecipe.time}</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-2xl border-b-4 border-madras-red">
                <p className="text-xs text-slate-500 uppercase font-bold">Difficulté</p>
                <p className="font-bold">{selectedRecipe.diff}</p>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Utensils className="text-madras-yellow" /> Ingrédients
              </h3>
              <ul className="space-y-3">
                {selectedRecipe.ingredients.map((ing, i) => (
                  <li key={i} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                    <div className="w-2 h-2 rounded-full bg-madras-red" />
                    {ing}
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-12">
              <h3 className="text-xl font-bold mb-4">Instructions</h3>
              <div className="space-y-6">
                {selectedRecipe.steps.map((step, i) => (
                  <div key={i} className="flex gap-4">
                    <span className="flex-none w-8 h-8 rounded-full bg-madras-blue text-white flex items-center justify-center font-bold">
                      {i + 1}
                    </span>
                    <p className="text-slate-600 leading-relaxed">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}