📱 ICÔNES PWA REQUISES

Placez les fichiers suivants dans le dossier public/:

1. icon-192x192.png (192x192 pixels)
2. icon-512x512.png (512x512 pixels)

Générateurs d'icônes en ligne:
- https://www.pwabuilder.com/imageGenerator
- https://realfavicongenerator.net/
- https://favicon.io/

Astuce: Utilisez un logo carré avec fond uni pour un meilleur rendu.
