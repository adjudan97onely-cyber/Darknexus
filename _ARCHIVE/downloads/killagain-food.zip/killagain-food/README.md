# 🌴 Killagain Food - PWA Recettes Créoles

Une application PWA moderne développée en React 18, Vite et Tailwind CSS, offrant un catalogue de recettes authentiques des Antilles (Guadeloupe & Martinique).

## 🚀 Caractéristiques
- **PWA Ready**: Installable sur mobile avec support hors-ligne.
- **Design Madras**: Interface colorée et vibrante aux couleurs des Caraïbes.
- **Favoris**: Sauvegarde locale des recettes préférées.
- **Recherche**: Filtre rapide par nom ou catégorie.

## 🛠 Installation

1. Cloner le dépôt
2. Installer les dépendances :
```bash
npm install
```
3. Lancer en développement :
```bash
npm run dev
```

## 📦 Déploiement Vercel
Le projet est configuré pour un déploiement instantané sur Vercel via le fichier `vercel.json` et la structure Vite standard.

## 🎨 Stack Technique
- React 18.3.1
- Vite
- Tailwind CSS
- Lucide React (Icons)
- Vite PWA Plugin